function it(testText, test) {
  console.log(testText)
  test();
};


// it('doubles the circle radius', function(){
//   var circle = new Circle();
//   circle.double();
//   expect(circle.radius).toEqual(20);
// });
